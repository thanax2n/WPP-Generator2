<?php

defined('ABSPATH') || exit;

use RTLWPSKWPPGNext\Uninstall;

Uninstall::init();
