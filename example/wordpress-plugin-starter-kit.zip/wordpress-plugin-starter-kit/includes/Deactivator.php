<?php

/**
 * The Deactivator class.
 *
 * This class runes actions while the plugin deactivation.
 */

namespace RTLWPSKWPPGNext;

class Deactivator
{

    public static function init(): string
    {

        return 'Deactivate';
    }
}
