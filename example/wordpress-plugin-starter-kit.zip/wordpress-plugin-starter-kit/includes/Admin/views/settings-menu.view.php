<?php

/**
 * Menu page.
*/

defined('ABSPATH') || exit;

printf('I am a view file of settings page and this message: <strong>%s</strong> is from my controller.', $message);
