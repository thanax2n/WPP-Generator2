<?php

/**
 * Menu page.
*/

defined('ABSPATH') || exit;

printf('I am a view file and this message: <strong>%s</strong> is from my controller.', $message);
