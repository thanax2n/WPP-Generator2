<?php

/**
 * MetaBox file not found.
 */

defined('ABSPATH') || exit;

printf(esc_html__('%s', 'wordpress-plugin-starter-kit'), '<h3 class="rtlwpsk-color-error">' . __('MetaBox file not found!', 'wordpress-plugin-starter-kit') . '</h3>');
