<?php

/**
 * Menu page.
*/

defined('ABSPATH') || exit;

printf('I am a view file of sub menu page and this message: <strong>%s</strong> is from my controller.', $message);
