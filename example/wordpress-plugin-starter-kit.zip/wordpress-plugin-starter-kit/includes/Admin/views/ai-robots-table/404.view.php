<?php

/**
 * VIEW.
 * 
 * Robot not found.
 */

defined('ABSPATH') || exit;

printf(esc_html__('%s', 'wordpress-plugin-starter-kit'), '<h3 class="rtlwpsk-color-error">' . $message . '</h3>');
