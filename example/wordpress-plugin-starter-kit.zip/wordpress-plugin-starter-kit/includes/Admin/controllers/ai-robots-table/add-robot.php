<?php

/**
 * CONTROLLER.
 * 
 * Add a robot page.
 * 
 * VIEW: \includes\Admin\views\ai-robots-table\add-robot.view.php
 */

defined('ABSPATH') || exit;

use RTLWPSKWPPGNext\Admin\Utilities\Tables\RobotsDataManager;

$instance = new RobotsDataManager();

rtlwpskView('ai-robots-table/add-robot', [
    'robotsTable'   => $instance
]);
