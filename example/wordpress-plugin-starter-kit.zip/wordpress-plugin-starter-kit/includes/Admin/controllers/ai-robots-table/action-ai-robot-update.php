<?php

/**
 * CONTROLLER.
 * 
 * Here fires edit an item action.
 */

defined('ABSPATH') || exit;

use RTLWPSKWPPGNext\Admin\Utilities\Tables\RobotsDataManager;

$instance = new RobotsDataManager();

$instance->editRobot();

rtlwpskGoBack(admin_url());
