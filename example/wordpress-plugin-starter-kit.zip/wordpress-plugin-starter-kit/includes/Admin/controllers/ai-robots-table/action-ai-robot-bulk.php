<?php

/**
 * CONTROLLER.
 * 
 * This file is used for Custom table actions.
 * When a user selects a bulk action 
 * here fires appropriate actions.
 */

defined('ABSPATH') || exit;

use RTLWPSKWPPGNext\Admin\Utilities\Tables\RobotsDataManager;

$instance = new RobotsDataManager();

$instance->bulkActions();

rtlwpskGoBack(admin_url());
