<?php

/**
 * Controller.
 * This file is used to display a main menu page.
 */

defined('ABSPATH') || exit;

rtlwpskView('main', [
    'message' => 'Hello, world!'
]);
