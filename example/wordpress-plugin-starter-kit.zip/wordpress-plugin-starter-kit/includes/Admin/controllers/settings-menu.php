<?php

/**
 * Controller.
 * This file is used to display a settings menu page.
 */

defined('ABSPATH') || exit;

rtlwpskView('settings-menu', [
    'message' => 'Hello, Settings Page!'
]);
