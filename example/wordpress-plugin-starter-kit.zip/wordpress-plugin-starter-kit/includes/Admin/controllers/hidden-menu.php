<?php

/**
 * Controller.
 * This file is used to display a hidden menu page.
 */

defined('ABSPATH') || exit;

rtlwpskView('sub-menu', [
    'message' => 'Hello, Hidden!'
]);
