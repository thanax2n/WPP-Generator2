<?php

/**
 * Short Code [react_js_app_short_code]
 * 
 * Here is a HTML markup of a shortcode.
 * 
 * Short Code: \includes\Frontend\Utilities\ShortCodeGenerator.php
 */

defined('ABSPATH') || exit;

echo '<div id="rtlwpskReactJsApp"></div>';
