<?php

/**
 * The FrontendSoul class.
 *
 * Here you can add or remove frontend features.
 */

namespace RTLWPSKWPPGNext\Frontend;

use RTLWPSKWPPGNext\Frontend\Utilities\WPEnqueueScripts;

use RTLWPSKWPPGNext\Frontend\Utilities\ShortCodeGenerator;

class FrontendSoul
{

    /**
     * Unique string to avoid conflicts.
     * 
     * @var string
     */
    protected $uniqueString = RTLWPSK_PLUGIN_UNIQUE_STRING;

    public function __construct()
    {

        $this->enqueueScripts();

        $this->shortCodes();
    }

    /**
     * Enqueue styles and scripts.
     * 
     * @return void
     */
    public function enqueueScripts(): void
    {

        (new WPEnqueueScripts)->enqueue();
    }

    /**
     * Add short codes.
     * 
     * @return void
     */
    public function shortCodes(): void
    {

        new ShortCodeGenerator;
    }
}
