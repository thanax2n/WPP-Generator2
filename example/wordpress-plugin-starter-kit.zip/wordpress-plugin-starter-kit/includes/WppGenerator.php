<?php

/**
 * The WppGenerator final class.
 *
 * Here you can turn off/on big part of features
 * of the plugin.
 */

namespace RTLWPSKWPPGNext;

use RTLWPSKWPPGNext\Admin\AdminSoul;
use RTLWPSKWPPGNext\Frontend\FrontendSoul;
use RTLWPSKWPPGNext\Features\FeaturesSoul;

final class WppGenerator
{

    public function __construct()
    {

        new AdminSoul;

        new FrontendSoul;

        new FeaturesSoul;
    }
}
