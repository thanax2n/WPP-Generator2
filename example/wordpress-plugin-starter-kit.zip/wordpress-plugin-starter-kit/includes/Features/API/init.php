<?php

defined('ABSPATH') || exit;

use RTLWPSKWPPGNext\Features\API\Routes\UpdatePostMetaImageRoute;
use RTLWPSKWPPGNext\Features\API\Routes\GetPostMetaImageRoute;
use RTLWPSKWPPGNext\Features\API\Routes\DeletePostMetaImageRoute;
use RTLWPSKWPPGNext\Features\API\Routes\TasksManager\GetTaskListRoute;
use RTLWPSKWPPGNext\Features\API\Routes\TasksManager\UpdateTaskListRoute;

// Next.js
use RTLWPSKWPPGNext\Features\API\Routes\NextJS\GetStylesRoute;
use RTLWPSKWPPGNext\Features\API\Routes\NextJS\GetAllPagesRoute;
use RTLWPSKWPPGNext\Features\API\Routes\NextJS\GetPageBySlugRoute;
use RTLWPSKWPPGNext\Features\API\Routes\NextJS\GetMenuItemsRoute;

if (!function_exists('rtlwpskInitializeRestRoutes')) {
    /**
     * Initialize and register all routes (endpoints).
     */
    function rtlwpskInitializeRestRoutes()
    {

        $routes = [
            new UpdatePostMetaImageRoute,
            new GetPostMetaImageRoute,
            new DeletePostMetaImageRoute,
            new GetTaskListRoute,
            new UpdateTaskListRoute,

            // Next.js
            new GetStylesRoute,
            new GetAllPagesRoute,
            new GetPageBySlugRoute,
            new GetMenuItemsRoute,
        ];

        foreach ($routes as $route) {

            $route->registerRoute();
        }
    }
}

add_action('rest_api_init', 'rtlwpskInitializeRestRoutes');
