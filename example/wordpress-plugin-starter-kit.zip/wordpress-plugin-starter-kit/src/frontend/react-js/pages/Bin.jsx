import { __ } from '@wordpress/i18n'
import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from "react-redux"
import { deleteTask, redoTask } from "@reactJs/store/slices/taskList/taskListSlice"
import SaveTasks from "@reactJs/components/SaveTasks"
import { NoTasksFound } from "@reactJs/components/NoTasksFound"

// const { __ } = wp.i18n // this for translate, because '@wordpress/i18n' does not work to display the translate text

const Bin = () => {

    const tasks = useSelector((state) => state.taskList.tasks)

    const dispatch = useDispatch()

    const handleRedo = (id) => {
        dispatch(redoTask({ taskId: id }))
    }

    const handleDelete = (id) => {

        dispatch(deleteTask({ taskId: id }))
    }

    return (
        <div className="rtlwpsk-container">
            <h2 className="rtlwpsk-category-title">{__('Completed Tasks', 'wordpress-plugin-starter-kit')}</h2>

            {
                Array.isArray(tasks) && (

                    !tasks.some(task => task.isDone === true) ? (

                        <NoTasksFound message={__('No completed tasks found', 'wordpress-plugin-starter-kit')} />
                    ) : (

                        <div className="rtlwpsk-menu-grid">
                            {tasks.map((task, index) => (
                                task.isDone === false ? null : (
                                    <div className="rtlwpsk-menu-item" key={index}>
                                        <div>
                                            <div className="rtlwpsk-menu-item-title">{task.title}</div>
                                            <div className="rtlwpsk-menu-item-description">{task.description}</div>
                                        </div>
                                        <div className="rtlwpsk-task-footer">
                                            <button className="rtlwpsk-redo-button" onClick={() => handleRedo(task.id)}>{__('Redo', 'wordpress-plugin-starter-kit')}</button>
                                            <button className="rtlwpsk-delete-button" onClick={() => handleDelete(task.id)}>{__('Delete', 'wordpress-plugin-starter-kit')}</button>
                                        </div>
                                    </div>
                                )
                            ))}
                        </div>
                    )
                )
            }

            {/* Save Tasks */}
            <SaveTasks />
        </div>
    )
}

export default Bin