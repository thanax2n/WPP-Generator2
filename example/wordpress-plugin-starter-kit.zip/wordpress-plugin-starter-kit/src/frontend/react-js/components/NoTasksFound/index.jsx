import React from 'react'
import { __ } from '@wordpress/i18n'

// const { __ } = wp.i18n // this for translate, because '@wordpress/i18n' does not work to display the translate text

export const NoTasksFound = ({ message }) => {
  return (
    <div className="rtlwpsk-menu-item rtlwpsk-no-tasks-found">
      <div className="rtlwpsk-menu-item-title">
        {message || __('No active tasks found', 'wordpress-plugin-starter-kit')}
      </div>
    </div>
  )
}