import { NavLink } from "react-router-dom"
import clsx from 'clsx'

export const Navigation = ({ navigation }) => {

  return (
    <nav className="rtlwpsk-nav-links">
      {navigation.map((item) => (
        <NavLink
          key={item.name}
          to={item.path}
          className={({ isActive }) =>
            clsx('rtlwpsk-nav-link', isActive && 'rtlwpsk-nav-link_active')
          }
        >
          {item.label}
        </NavLink>
      ))}
    </nav>
  )
}