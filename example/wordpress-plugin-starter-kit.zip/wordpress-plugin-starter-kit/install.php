<?php

defined('ABSPATH') || exit;

use RTLWPSKWPPGNext\Activator;
use RTLWPSKWPPGNext\Deactivator;

/*
* Run during an activation.
*/

register_activation_hook(RTLWPSK_PLUGIN_BASE_NAME, [Activator::class, 'init']);

/*
* Run during a deactivation.
*/

register_deactivation_hook(RTLWPSK_PLUGIN_BASE_NAME, [Deactivator::class, 'init']);
