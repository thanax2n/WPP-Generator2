const Loading = async () => {

    return (
        <div>Loading ...</div>
    )
}

export default Loading